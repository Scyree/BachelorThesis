﻿$(document).ready(function () {
    $("#displayOption").click(function () {
        $("#deleteProfile").modal('show');
    });
});