﻿
namespace ExploreBooks.Models.ManageViewModels
{
    public class ProfileViewModel
    {
        public string Folder { get; set; }

        public string ImageName { get; set; }

        public string StatusMessage { get; set; }
    }
}
