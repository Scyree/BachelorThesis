﻿using System.Collections.Generic;
using Domain.Data;

namespace Business.Interfaces
{
    public interface IApplicationFollowLogic
    {
        void FollowUser(string userId, string followedId);
        void UnfollowUser(string userId, string followedId);
        int GetNumberOfFollowedPeople(string userId);
        int GetNumberOfFollowers(string userId);
        List<ApplicationUser> GetFollowedPeople(string userId);
        List<ApplicationUser> GetFollowers(string userId);
        bool CheckIfAlreadyFollowed(string userId, string followedId);
    }
}
