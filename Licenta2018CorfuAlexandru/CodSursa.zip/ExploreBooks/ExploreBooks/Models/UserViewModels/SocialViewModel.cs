﻿
namespace ExploreBooks.Models.UserViewModels
{
    public class SocialViewModel
    {
        public string Id { get; set; }

        public string Username { get; set; }
    }
}
