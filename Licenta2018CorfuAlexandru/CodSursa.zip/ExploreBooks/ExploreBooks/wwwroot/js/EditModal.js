﻿$(document).ready(function () {
    $("#displayEditOption").click(function () {
        $("#editModal").modal('show');
    });
});