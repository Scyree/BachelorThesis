﻿
namespace Service.Services
{
    public enum UserRoles
    {
        Owner,
        Administrator,
        User
    }
}
