﻿
namespace ExploreBooks.Models.ManageViewModels
{
    public class DeleteProfileViewModel
    {
        public string Id { get; set; }

        public string StatusMessage { get; set; }
    }
}
